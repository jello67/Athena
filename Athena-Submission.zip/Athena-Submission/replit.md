# replit.md

## Overview

This is a simple educational website about fruits, built as a static HTML site. The project appears to be a beginner-level web development exercise focused on learning HTML structure, CSS styling, and basic navigation. The website provides information about different types of fruits, their benefits, and categorizes them into citrus fruits, berries, and tropical fruits.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Static HTML Website**: The application consists of multiple standalone HTML pages with embedded CSS styling
- **Navigation Structure**: Implements a simple multi-page navigation system linking between different fruit categories
- **Styling Approach**: Uses inline CSS within `<style>` tags in each HTML file, with gradient backgrounds and responsive design elements
- **Page Organization**: Follows a hub-and-spoke model with `index.html` as the main entry point and category-specific pages for different fruit types

### Content Structure
- **Home Page**: Main landing page (`index.html`) introducing the fruit topic
- **Category Pages**: Dedicated pages for fruits (`fruits.html`), benefits (`benefits.html`), citrus fruits (`citrus.html`), berries (`berries.html`), and tropical fruits (`tropical.html`)
- **Consistent Navigation**: Each page includes a navigation menu linking to all other sections
- **Visual Design**: Implements color-coded themes for different fruit categories (salmon for general fruits, peachpuff for citrus, lavender for berries, orange gradient for tropical)

### Technical Implementation
- **Pure HTML/CSS**: No JavaScript frameworks or build tools required
- **Embedded Styling**: CSS is written directly in HTML files rather than separate stylesheets
- **Responsive Elements**: Uses flexbox layouts and container-based design for basic responsiveness
- **Cross-page Consistency**: Navigation menu structure is replicated across all pages for consistent user experience

## External Dependencies

### Assets and Resources
- **Images**: References internet-sourced images (noted in footer of index.html)
- **Fonts**: Uses serif font family (browser default)
- **No External Libraries**: Project relies entirely on native HTML/CSS without external frameworks or CDNs
- **No Build Tools**: Static files can be served directly without compilation or preprocessing

### Development Environment
- **File-based Hosting**: Designed to run on any static web server or file system
- **No Backend Requirements**: Pure frontend implementation with no server-side processing needed
- **Browser Compatibility**: Uses standard HTML5 and CSS3 features supported by modern browsers